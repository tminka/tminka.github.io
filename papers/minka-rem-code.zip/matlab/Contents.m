% Code to accompany the paper "Using lower bounds to approximate integrals"
% By Tom Minka
% 10-Apr-2015
%
% test_normal_*    - Generate figures for the paper.
% helpers/*        - Routines used by the tests.  

% Generate figures 3,4 of the paper.
% Mixture of two gaussians with both means free.

% set fignumber to 1,2, or 3
fignumber = 3;
prefix = 'normal_m_contour_';

addpath('helpers')
%addpath(fullfile(pkg_dir,'density'))
%addpath(fullfile(pkg_dir,'hide'))

vb_error = [];
map_error = [];
laplace_error = [];

niters = 1;
n = 100;
limit = 1;
res = 20;
if fignumber == 3
	mms = [0:0.1:1 1.5 2];
	niters = 10;
	n = 1000;
	limit = 6;
	res = 100;
elseif fignumber == 1
	mms = 1/2;
else
	mms = 0;
end
for mi = 1:length(mms)

m = mms(mi);
v = {1 1};
prior = {normal_density(-1, 100) normal_density(1, 100)};
density1 = normal_density(-m, v{1});
density2 = normal_density(m, v{2});
density1 = set_prior(density1, prior{1});
density2 = set_prior(density2, prior{2});
mix = mixture_density([1 1], density1, density2);

for iter = 1:niters
data = sample(mix, n);
if fignumber < 3
	filename = sprintf('data_normal_m_%d.mat', fignumber);
	if exist(filename)
		load(filename);
	else
		save(filename, 'data');
	end
else
	fprintf('m = %g trial %g\n', m, iter);
end

% Reverse EM for normal means %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Running Variational bound')
vb = struct;
flops(0);
vb.q = vb_normal_m_train(prior, v, data, 0.5);

% ML fit %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Running MAP')
figure(1)
clf
fit = train(mix, data);
map = struct;
map.q = classify(fit, data);

% Laplace's method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

c = get_components(fit);
laplace_m = [get_mean(c{1}); get_mean(c{2})];
laplace_k = sum(logProb(fit, data)) + logProb(prior{1}, laplace_m(1)) + ...
    logProb(prior{2}, laplace_m(2));
% laplace_h is the negative Hessian
laplace_h = diag(1./[get_cov(prior{1}) get_cov(prior{2})]);
laplace_h = laplace_h + diag(row_sum(map.q));
% using laplace_h at this point will mimic the MAP bound
g = repmat(data, 2, 1) - repmat(laplace_m, 1, cols(data));
laplace_h = laplace_h - diag(row_sum(map.q.*(g.^2)));
qg = map.q.*g;
laplace_h = laplace_h + qg*qg';
if 0
	% check that the gradient is zero
	prior_m = [get_mean(prior{1}); get_mean(prior{2})];
	dtheta = (prior_m - laplace_m)/get_cov(prior{1}) + row_sum(qg)
end

% Plot the fits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
inc = 2*limit/res;
r = -limit:inc:limit;
ms = ndgridmat(r,r)';
exact = zeros(length(ms),1);
map.bound = zeros(length(ms),1);
vb.bound = zeros(length(ms),1);
for i = 1:length(ms)
  obj = set_component(fit, 1, set_mean(density1, ms(1,i)));
  obj = set_component(obj, 2, set_mean(density2, ms(2,i)));
  e = logProb(prior{1}, ms(1,i)) + logProb(prior{2}, ms(2,i));
  exact(i) = sum(logProb(obj, data)) + e;
  map.bound(i) = sum(logProb_bound(obj, data, map.q)) + e;
  vb.bound(i) = sum(logProb_bound(obj, data, vb.q)) + e;
end
exact = reshape(exact, length(r), length(r));
map.bound = reshape(map.bound, length(r), length(r));
vb.bound = reshape(vb.bound, length(r), length(r));

diff = ms - repmat(laplace_m, 1, cols(ms));
laplace_approx = laplace_k -0.5*col_sum(diff.*(laplace_h*diff));
laplace_approx = reshape(laplace_approx, length(r), length(r));

if niters == 1 && n < 1000
	suffix = [num2str(fignumber) '.eps'];
	figure(1)
	contour(r, r, exp(exact), 3, 'b')
	hold on
	hold off
	xlabel('m1')
	ylabel('m2')
	legend('Exact')
	set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 4])
	print('-depsc',[prefix 'exact' suffix])

	figure(2)
	contour(r, r, exp(exact), 3, 'b:')
	hold on
	contour(r, r, exp(vb.bound), 3, 'g')
	hold off
	xlabel('m1')
	ylabel('m2')
	legend('Exact','VB')
	set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 4])
	print('-depsc',[prefix 'vb' suffix])

	figure(3),clf
	contour(r, r, exp(exact), 3, 'b:')
	hold on
	contour(r, r, exp(laplace_approx), 3, 'g')
	hold off
	xlabel('m1')
	ylabel('m2')
	legend('Exact','Laplace')
	set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 4])
	print('-depsc',[prefix 'laplace' suffix])
end

% Compute the integral approximations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
results = struct;
results.Exact.e = logSum(exact(:))+2*log(inc);
results.MAP.ehat = logSum(map.bound(:))+2*log(inc);
results.MAP.e = vb_normal_m_bound(prior, v, data, map.q);
results.VB.ehat = logSum(vb.bound(:))+2*log(inc);
results.VB.e = vb_normal_m_bound(prior, v, data, vb.q);
results.Laplace.ehat = logSum(laplace_approx(:))+2*log(inc);
if isposdef(laplace_h)
	results.Laplace.e = laplace_k-0.5*logdet(laplace_h/2/pi);
else
  % sometimes Laplace fails because MAP doesn't converge
  disp('Laplace failed')
  results.Laplace.e = results.Laplace.ehat;
end

if fignumber < 3
disp('Log Evidence:')
algs = fieldnames(results);
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'e')
    if ~isfield(r,'ehat')
			fprintf('  %-7s = %g\n', algs{a}, r.e);
		else
			fprintf('  %-7s = %g (over entire space = %g)\n', algs{a}, r.ehat, r.e);
		end
  end
end
end

vb_error(mi, iter) = exp(results.VB.ehat - results.Exact.e);
map_error(mi, iter) = exp(results.MAP.ehat - results.Exact.e);
laplace_error(mi, iter) = exp(results.Laplace.ehat - results.Exact.e);
% end the iter loop
end

% end the m loop
end

if length(mms) > 1
	%save results_m_evidence.mat mms vb_error map_error laplace_error
	%load results_m_evidence.mat
	figure(3)
	%vb_stddev = sqrt(var(vb_error')/cols(vb_error))';
	%laplace_stddev = sqrt(var(laplace_error')/cols(laplace_error))';
	vb_stddev = std(vb_error,0,2);
	laplace_stddev = std(laplace_error,0,2);
	vb_mean = mean(vb_error,2);
	map_mean = mean(map_error,2);
	laplace_mean = mean(laplace_error,2);
	errorbar(mms, laplace_mean, laplace_stddev, 'g')
	hold on
	errorbar(mms, vb_mean, vb_stddev, 'b')
	%plot(mms, map_mean, 'r')
	hold off
	axis_pct
	xlabel('m2')
	ylabel('Fraction of exact evidence')
	legend('Laplace','VB')
	set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 3])
	print -depsc normal_m_evidence.eps
end

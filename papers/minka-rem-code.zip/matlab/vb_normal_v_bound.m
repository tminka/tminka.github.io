function p = vb_normal_v_bound(prior, m, data, q)
% prior is a cell array of inverse Wishart prior densities for the variances.
% m is a cell array of means for the components.
% data is a matrix of columns.
% q is a matrix of columns.
% p is a scalar.

J = rows(q);
[d,N] = size(data);

n = row_sum(q);
p = -sum(sum(q.*log(q))) + sum(n.*log(1/J));

% loop components
for j = 1:J
  diff = data - repmat(m{j}, 1, N);
  s0 = get_s(prior{j});
  n0 = get_n(prior{j});
  s = vtrans(outer(diff,diff)*q(j,:)',d) + s0;
  p = p + wishart_z(n(j)+n0,d) - wishart_z(n0,d) - n(j)*d/2*log(pi);
  p = p + n0/2*logdet(s0) - (n(j)+n0)/2*logdet(s);

  if 0
    inc = 0.01;
    vs = inc:inc:10;
    f = logProb(prior{j}, vs) - n(j)/2*log(2*pi*vs) -0.5*(s-s0)./vs;
    plot(vs, exp(f))
    row_logSum(f) + log(inc)
    break
  end
end

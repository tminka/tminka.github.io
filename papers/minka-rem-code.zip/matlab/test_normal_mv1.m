% Generate figure 6 of the paper.
% Mixture of Gaussians with one component free.

addpath('helpers')
%addpath(fullfile(pkg_dir,'density'))

small = 1e-2;
huge = 1e10;
prior = {normal_wishart_density(1, small, small, small) ...
    normal_wishart_density(2, inf, huge, huge)};
density1 = normal_density(0, 1);
density2 = normal_density(2, 1);
density1 = set_prior(density1, prior{1});
density2 = set_prior(density2, prior{2});
mix = mixture_density([1 1], density1, density2);

n = 100;
filename = 'data_normal_mv.mat';
if exist(filename)
	load(filename);
else
	data = sample(mix, n);
	save(filename,'data');
end

% Reverse EM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vb.q = vb_normal_mv_train(prior, data);

% ML fit %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fit = train(mix, data);
map.q = classify(fit, data);

% Laplace's method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find the MAP estimate of log(v1)
eff_prior = set_n(prior{1}, get_n(prior{1})-2);
eff_mix = set_component(mix, 1, set_prior(density1, eff_prior));
fit2 = train(eff_mix, data);
mbr2 = classify(fit2, data);

c = get_components(fit2);
laplace_m = [get_mean(c{1}); get_cov(c{1})];
laplace_k = sum(logProb(fit2, data)) + logProb(prior{1}, laplace_m) + ...
    log(laplace_m(2));
diff = data - repmat(laplace_m(1), 1, cols(data));
diff2 = diff.^2;
g = [];
g(1,:) = diff/laplace_m(2);
g(2,:) = -0.5 + diff2/2/laplace_m(2);
laplace_h = [];
laplace_h(1,1) = sum(mbr2(1,:)) + get_k(prior{1});
laplace_h(1,2) = sum(mbr2(1,:).*diff);
laplace_h(2,1) = laplace_h(1,2);
laplace_h(2,2) = sum(mbr2(1,:).*diff2)/2 + ...
    laplace_m(1)^2*get_k(prior{1})/2 + get_s(prior{1})/2;
laplace_h = laplace_h/laplace_m(2);
mg = repmat(mbr2(1,:).*mbr2(2,:), 2, 1) .* g;
laplace_h = laplace_h - g*mg';

% Plot the fits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m_inc = 0.05;
rm = -1:m_inc:1;
inc = 0.1;
rv = inc:inc:5;
ms = ndgridmat(rm,rv);
exact = struct;
exact.f = zeros(rows(ms),1);
map.f = zeros(rows(ms),1);
vb.f = zeros(rows(ms),1);
for i = 1:rows(ms)
  obj = set_component(fit, 1, normal_density(ms(i,1), ms(i,2)));
  e = logProb(prior{1}, ms(i,:)');
  exact.f(i) = sum(logProb(obj, data)) + e;
  map.f(i) = sum(logProb_bound(obj, data, map.q)) + e;
  vb.f(i) = sum(logProb_bound(obj, data, vb.q)) + e;
end  
exact.f = reshape(exact.f, length(rm), length(rv))';
map.f = reshape(map.f, length(rm), length(rv))';
vb.f = reshape(vb.f, length(rm), length(rv))';

diff = [];
diff(1,:) = ms(:,1) - laplace_m(1);
diff(2,:) = log(ms(:,2)/laplace_m(2));
laplace.f = laplace_k -0.5*col_sum(diff.*(laplace_h*diff));
laplace.f = laplace.f - log(ms(:,2)');
laplace.f = reshape(laplace.f, length(rm), length(rv))';

results = struct;
results.Exact = exact;
results.MAP = map;
results.VB = vb;
results.Laplace = laplace;

ax = [-0.5 0.5 0.25 2];
figure(1)
contour(rm, rv, exp(exact.f), 5, 'b')
xlabel('m')
ylabel('v')
legend('Exact')
axis(ax)
print -depsc normal_mv_contour_exact.eps

figure(2)
contour(rm, rv, exp(exact.f), 5, 'b:')
hold on
contour(rm, rv, exp(vb.f), 5, 'g')
hold off
xlabel('m')
ylabel('v')
legend('Exact','VB')
axis(ax)
print -depsc normal_mv_contour_vb.eps

figure(3),clf
contour(rm, rv, exp(exact.f), 5, 'b:')
hold on
contour(rm, rv, exp(laplace.f), 5, 'g')
hold off
xlabel('m')
ylabel('v')
legend('Exact','Laplace')
axis(ax)
print -depsc normal_mv_contour_laplace.eps

% Compute the integral approximations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

results.Exact.e = logSum(exact.f(:))+log(m_inc*inc);
results.MAP.ehat = logSum(map.f(:))+log(m_inc*inc);
results.MAP.e = vb_normal_mv_bound(prior, data, map.q);
results.VB.ehat = logSum(vb.f(:))+log(m_inc*inc);
results.VB.e = vb_normal_mv_bound(prior, data, vb.q);
results.Laplace.ehat = logSum(laplace.f(:))+log(m_inc*inc);
results.Laplace.e = laplace_k-0.5*logdet(laplace_h/2/pi);

disp('Log Evidence:')
algs = fieldnames(results);
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'e')
    if ~isfield(r,'ehat')
			fprintf('  %-7s = %g\n', algs{a}, r.e);
		else
			fprintf('  %-7s = %g (over entire space = %g)\n', algs{a}, r.ehat, r.e);
		end
  end
end
for a = 1:length(algs)
	r = results.(algs{a});
	if isfield(r,'e')
		fprintf('%s captures %2.0f%% of the total mass\n', algs{a}, 100*exp(r.e - results.Exact.e));
	end
end

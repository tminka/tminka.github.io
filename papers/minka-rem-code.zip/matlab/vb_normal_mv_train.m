function q = vb_normal_mv_train(prior, data)
% prior is a cell array of normal-Wishart prior densities for the components.

J = length(prior);
[d,N] = size(data);
q = ones(J,N)/J;
%q = repmat([0.1;0.9], 1, N);
%q = repmat([0.9;0.1], 1, N);
for iter = 1:100
  old_q = q;
  % loop components
  for j = 1:J
    nj = sum(q(j,:));
    xj = (data * q(j,:)')/nj;
    s = vtrans(outer(data,data) * q(j,:)', d);
    s = s - nj*xj*xj';
    % this code works even if k0 = inf
    k0 = get_k(prior{j});
    m0 = get_mean(prior{j});
    m = (xj*nj/k0 + m0)/(nj/k0 + 1);
    diff = xj - m0;
    s = s + get_s(prior{j}) + (nj/(nj/k0+1))*(diff*diff');
    n0 = get_n(prior{j});
    z = logdet(s) -d*log(2);
    for i = 1:d
      z = z - digamma((nj+n0+1-i)/2);
    end
    diff = data - repmat(m, 1, N);
    q(j,:) = -z/2 -0.5*(nj+n0)*col_sum(diff.*(inv(s)*diff)) -0.5*d/(nj+k0);
  end
  q = q - repmat(logSum(q), rows(q), 1);
  q = exp(q);
  if norm(q - old_q) < 1e-5
    break
  end
end


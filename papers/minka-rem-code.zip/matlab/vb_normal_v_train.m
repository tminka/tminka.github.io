function q = vb_normal_v_train(prior, m, data)
% prior is a cell array of inverse Wishart prior densities for the variances.
% m is a cell array of means for the components.
% data is a matrix of columns.

J = length(prior);
[d,N] = size(data);
q = ones(J,N)/J;
for iter = 1:100
  old_q = q;
  n = row_sum(q);
  % loop components
  for j = 1:J
    diff = data - repmat(m{j}, 1, N);
    s0 = get_s(prior{j});
    n0 = get_n(prior{j});
    s = vtrans(outer(diff,diff)*q(j,:)',d) + s0;
    z = log(s) - d*log(2);
    for i = 1:d
      z = z - digamma((n(j)+n0+1-i)/2);
    end
    iv = (n(j)+n0)/s;
    q(j,:) = -0.5*z -0.5*col_sum(diff.*(iv*diff));
  end
  q = q - repmat(logSum(q), rows(q), 1);
  q = exp(q);
  if norm(q - old_q) < 1e-5
    break
  end
end

  

function p = vb_normal_mv_bound(prior, data, q)
% prior is a cell array of normal-Wishart prior densities.
% data is a matrix of columns.
% q is a matrix of columns.
% p is a scalar.

J = rows(q);
[d,N] = size(data);

n = sum(q');
p = -sum(sum(q.*log(q))) + sum(n.*log(1/J));

% loop components
for j = 1:J
  if 1
    m = (data * q(j,:)')/n(j);
    s = vtrans(outer(data,data) * q(j,:)', d);
    s = s - n(j)*m*m';
    m0 = get_mean(prior{j});
    % this code works even if k0 = inf
    k0 = get_k(prior{j});
    s0 = get_s(prior{j});
    n0 = get_n(prior{j});
    s = s + s0 + (n(j)/(1+n(j)/k0))*(m-m0)*(m-m0)';
    p = p + wishart_z(n(j)+n0,d) - wishart_z(n0,d) - n(j)*d/2*log(pi);
    p = p + d/2*log(1/(1+n(j)/k0)) + n0/2*logdet(s0) - (n(j)+n0)/2*logdet(s);
  else
    c = diag(q(j,:)) - q(j,:)'*q(j,:)/(get_n(prior{j}) + nj(j));
    obj = matrix_t_density(get_mean(prior{j}), get_s(prior{j}), c, ...
	get_n(prior{j}));
    p = p + logProb(obj, data, nj(j));
  end
end

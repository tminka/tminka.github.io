function a = get_a(obj)

a = obj.a;

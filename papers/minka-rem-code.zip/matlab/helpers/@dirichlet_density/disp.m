function disp(obj)

disp('a = ');
disp(obj.a);

function n = get_n(obj)

n = obj.n;

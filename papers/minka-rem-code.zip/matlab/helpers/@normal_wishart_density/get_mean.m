function m = get_mean(obj)

m = obj.mean;

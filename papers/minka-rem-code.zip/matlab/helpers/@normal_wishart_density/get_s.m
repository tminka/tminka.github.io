function s = get_s(obj)

s = obj.s;

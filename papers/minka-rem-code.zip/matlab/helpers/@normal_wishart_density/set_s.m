function obj = set_s(obj, s)

obj.s = s;

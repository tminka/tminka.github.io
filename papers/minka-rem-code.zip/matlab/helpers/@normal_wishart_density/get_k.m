function k = get_k(obj)

k = obj.k;

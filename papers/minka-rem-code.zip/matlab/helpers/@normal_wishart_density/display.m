function disp(obj)

disp(['mean = ']);
disp(obj.mean);
disp(['k = ']);
disp(obj.k);
disp(['s = ']);
disp(obj.s);
disp(['n = ']);
disp(obj.n);

function obj = set_n(obj, n)

obj.n = n;

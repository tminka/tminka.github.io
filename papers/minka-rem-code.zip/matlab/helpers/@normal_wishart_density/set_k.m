function obj = set_k(obj, k)

obj.k = k;

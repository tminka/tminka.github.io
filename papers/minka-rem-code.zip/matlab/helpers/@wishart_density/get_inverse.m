function i = get_inverse(obj)

i = obj.inverse;

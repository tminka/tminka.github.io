function disp(obj)

disp('s = ');
disp(obj.s);
disp('n = ');
disp(obj.n);
if obj.inverse
  disp('inverse')
end

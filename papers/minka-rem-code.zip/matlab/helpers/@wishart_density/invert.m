function obj = invert(obj)

obj.inverse = ~obj.inverse;

function s = col_logSum(a)

if isa(a, 'cell')
  s = cell(size(a));
  for i = 1:prod(size(a))
    s{i} = col_logSum(a{i});
  end
  return
end

% subtract the largest in each column
[y, i] = max(a);
a = a - repmat(y, rows(a), 1);
s = y + log(col_sum(exp(a)));
i = find(~isfinite(y));
if ~isempty(i)
  s(i) = y(i);
end

function s = logSum(a, b)
% Returns log(exp(a) + exp(b)) while avoiding numerical underflow.
% If one argument is given, returns the logSum of each column.

if nargin > 1
  
  % Make A the larger number
  i = find(a < b);
  t = zeros(size(a));
  t(i) = a(i);
  a(i) = b(i);
  b(i) = t(i);

  s = a + log(1 + exp(b-a));
  i = find(~finite(a));
  if ~isempty(i)
    s(i) = a(i);
  end

else

  s = col_logSum(a);
  
end

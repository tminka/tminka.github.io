function obj = set_mean(obj, mean)

obj.mean = mean;

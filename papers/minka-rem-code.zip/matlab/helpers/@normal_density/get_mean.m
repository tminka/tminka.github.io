function x = get_mean(obj)

x = obj.mean;

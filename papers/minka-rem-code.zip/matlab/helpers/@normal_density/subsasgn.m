function a = subsasgn(varargin)

a = builtin('subsasgn',varargin{:});

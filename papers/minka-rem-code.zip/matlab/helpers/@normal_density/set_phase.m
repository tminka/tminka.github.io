function obj = set_phase(obj, phase)

obj.phase = phase;

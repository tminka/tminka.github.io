function density = get_prior(obj)

density = obj.prior;

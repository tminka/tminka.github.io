function obj = set_prior(obj, prior)

obj.prior = prior;

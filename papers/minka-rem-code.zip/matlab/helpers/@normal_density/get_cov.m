function x = get_cov(obj)

x = obj.cov;

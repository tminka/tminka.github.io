function obj = set_train_components(obj, t)

obj.train_components = t;

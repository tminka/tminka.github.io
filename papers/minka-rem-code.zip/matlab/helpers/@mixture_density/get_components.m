function c = get_components(obj)
% Returns a cell array of the components of obj.

c = obj.components;

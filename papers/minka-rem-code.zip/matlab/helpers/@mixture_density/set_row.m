function obj = set_row(obj, row)

obj.row = row;

function w = get_weights(obj)

w = obj.weights;

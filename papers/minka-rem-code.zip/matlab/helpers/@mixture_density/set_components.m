function obj = set_components(obj, c)

obj.components = c;

function obj = set_temperature(obj, temperature)

obj.temperature = temperature;

function obj = set_weights(obj, w)

obj.weights = w;

function obj = set_train_weights(obj, t)

obj.train_weights = t;

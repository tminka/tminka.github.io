function obj = set_weights_prior(obj, prior)

obj.weights_prior = prior;

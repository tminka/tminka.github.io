function obj = set_component(obj, i, c)

obj.components{i} = c;

function e = normal_bound_fcn(kby, ms, exact)

[k,b,y] = deal(kby(1), kby(2), kby(3));
g = k -1/2*b*((y-ms).^2)';
e = min(exact-g);
e = abs(e);

% Generate figures 1,2 of the paper.
% Mixture of two gaussians with one mean free.
% also see tex/phd/tangent/matlab/clutter/test_clutter.m

% set fignumber to 1 or 2
fignumber = 1;
logscale = 0;

addpath('helpers')
%addpath(fullfile(pkg_dir,'density'))
%addpath(fullfile(pkg_dir,'hide'))
%addpath('z:/tex/phd/tangent/matlab/clutter')

v = {1 1};
d = 1;
w = 1/2;
prior = {normal_density(zeros(d,1), 10^2*eye(d)) ...
         normal_density(zeros(d,1), 0*eye(d))};
density1 = normal_density(2*ones(d,1), v{1}*eye(d));
density2 = normal_density(zeros(d,1), v{2}*eye(d));
density1 = set_prior(density1, prior{1});
density2 = set_prior(density2, prior{2});
mix = mixture_density([1-w w], density1, density2);

if fignumber == 2
	n = 1;
	data = 1;
elseif exist('data_normal_m1.mat')
	load data_normal_m1.mat
else
	n = 10;
	data = sample(mix, n);
	save data_normal_m1.mat data
end
if 0
	% big dataset case
	n = 1000;
	data = sample(mix, n);
end

results = struct;
p2 = logProb(density2, data);

% Approximate the posterior distribution %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Running Variational bound')
flops(0);
[rem.q,rem.run] = vb_normal_m_train(prior, v, data, w);
results.VB = rem;

disp('Running Laplace')
flops(0);
[laplace.e,laplace.m,laplace.h,laplace.k,laplace.run] = laplace_normal_m1(prior{1}, data, v{1}, p2, w);
laplace.v = 1/laplace.h;
results.Laplace = laplace;

disp('Running MAP')
fit = train(mix, data);
map = struct;
map.q = classify(fit, data);
% hard assignment
hard = struct;
hard.q = map.q;
hard.q(find(map.q < 0.5)) = 0;
hard.q(find(map.q > 0.5)) = 1;

if 0
% another way to do Laplace's method
c = get_components(fit);
laplace.m = get_mean(c{1});
laplace.k = sum(logProb(fit, data)) + logProb(prior{1}, laplace.m);
g = data - repmat(laplace.m, 1, cols(data));
s = row_sum(map.q(1,:).*map.q(2,:).*(g.^2));
laplace.h = 1/get_cov(prior{1}) + sum(map.q(1,:)) - s;
end

% Plot the fits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if fignumber == 2
	ms = linspace(-5,10,400);
else
	ms = linspace(-2,4,400);
end
inc = ms(2)-ms(1);
exact = struct;
exact.f = zeros(length(ms),1);
map.f = zeros(length(ms),1);
hard.f = zeros(length(ms), 1);
rem.f = repmat(-Inf,length(ms),1);
for i = 1:length(ms)
  obj = set_component(mix, 1, set_mean(density1, ms(i)));
  exact.f(i) = sum(logProb(obj, data)) + logProb(prior{1}, ms(i));
	map.f(i) = sum(logProb_bound(obj, data, map.q)) + logProb(prior{1}, ms(i));
  hard.f(i) = sum(logProb_bound(obj, data, hard.q)) + logProb(prior{1}, ms(i));
  rem.f(i) = sum(logProb_bound(obj, data, rem.q)) + logProb(prior{1}, ms(i));
end

exact.e = logSum(exact.f)+log(inc);
exact.m = sum(ms'.*exp(exact.f - exact.e + log(inc)));
exact.v = sum((ms - exact.m).^2*exp(exact.f - exact.e + log(inc)));
results.Exact = exact;

map.e = logSum(map.f)+log(inc);
map.ehat = vb_normal_m_bound(prior, v, data, map.q);
results.MAP = map;
hard.e = logSum(hard.f)+log(inc);
hard.ehat = vb_normal_m_bound(prior, v, data, hard.q);
results.Hard = hard;

if isfield(results,'VB')
  results.VB.f = rem.f;
  results.VB.ehat = logSum(rem.f)+log(inc);
  results.VB.e = vb_normal_m_bound(prior, v, data, rem.q);
  results.VB.m = rem.run.m(end);
	results.VB.v = rem.run.v(end);
end

laplace.f = laplace.k -0.5*laplace.h*((ms - laplace.m).^2)';
results.Laplace = laplace;
results.Laplace.ehat = logSum(laplace.f)+log(inc);

% a simple unbiased estimate of m
results.Unbiased.m = 2*mean(data);

% Best Gaussian bound %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if 0
c = get_components(fit);
y = get_mean(c{1});
k = sum(logProb(fit, data)) + logProb(prior{1}, y);
b = 5;
kby = fmins('normal_bound_fcn', [k;b;y], [], [], ms, exact);
[k,b,y] = deal(kby(1), kby(2), kby(3));
ep_approx = k -1/2*b*((y-ms).^2)';

min(exact - ep_approx)
end

% for n = 10, vb_bound is very close to the best gaussian bound

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

color.Exact = 'b';
color.Laplace = 'g';
color.EP = 'c';
color.VB = 'r';
color.MAP = 'r:';
color.Hard = 'k';

figure(3);clf

algs = {'Exact','Laplace','VB','MAP','Hard'};
legtxt = {};
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'f') && isfield(color,algs{a})
		if logscale
			y = r.f;
		else
			y = exp(r.f);
		end
    figure(3);plot(ms, y, color.(algs{a}));hold on;
    legtxt{end+1} = algs{a};
  end
end

figure(3)
xlabel('m')
if logscale
	ylabel('log p(m,D)')
else
	ylabel('p(m,D)')
end
%xlabel('theta')
%ylabel('p(theta,D)')
hold off
legloc = 'NorthEast';
if logscale
	legloc = 'South';
end
legend(legtxt,'Location',legloc);
set(gca,'ytick',[])
set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 3])
if fignumber == 1
	filename = 'normal_m1_n10';
else
	filename = 'normal_m1_n1';
end
if logscale
	filename = [filename '_log'];
end
filename = [filename '.eps'];
print('-depsc',filename);

% Compute the integral approximations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Log Evidence:')
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'e')
    if ~isfield(r,'ehat')
			fprintf('  %-7s = %g\n', algs{a}, r.e);
		else
			fprintf('  %-7s = %g (over entire space = %g)\n', algs{a}, r.ehat, r.e);
		end
  end
end
if fignumber ~= 2
	for a = 1:length(algs)
		r = results.(algs{a});
		if isfield(r,'e')
			fprintf('%s captures %2.0f%% of the total mass\n', algs{a}, 100*exp(r.e - results.Exact.e));
		end
	end
end

% Compare the posterior means %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp(' ')
disp('Posterior mean:')
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'m')
    fprintf('  %-8s = %g\n', algs{a}, r.m);
  end
end

% Compare the posterior variances %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp(' ')
disp('Posterior variance:')
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'v')
    fprintf('  %-7s = %g\n', algs{a}, r.v);
  end
end

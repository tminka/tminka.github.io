% Generate figure 5 of the paper.
% Mixture of two Gaussians with one variance parameter free.

logscale = 0;

addpath('helpers')
%addpath(fullfile(pkg_dir,'density'))
%addpath(fullfile(pkg_dir,'hide'))

small = 1e-2;
huge = 1e10;
prior = {wishart_density(small, small, 'inverse') ...
    wishart_density(huge, huge, 'inverse')};
m = {0 2};
density1 = normal_density(m{1}, 1);
density2 = normal_density(m{2}, 1);
density1 = set_prior(density1, prior{1});
density2 = set_prior(density2, prior{2});
mix = mixture_density([1 1], density1, density2);

n = 10;
filename = 'data_normal_v.mat';
if exist(filename)
	load(filename);
else
	data = sample(mix, n);
	save(filename,'data');
end

% Reverse EM %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vb.q = vb_normal_v_train(prior, m, data);

% ML fit %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fit = train(mix, data);
map.q = classify(fit, data);

% Laplace's method %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find the MAP estimate of log(v1)
eff_prior = set_n(prior{1}, get_n(prior{1})-2);
eff_mix = set_component(mix, 1, set_prior(density1, eff_prior));
fit2 = train(eff_mix, data);
mbr2 = classify(fit2, data);

c = get_components(fit2);
laplace_m = get_cov(c{1});
laplace_k = sum(logProb(fit2, data)) + logProb(prior{1}, laplace_m) + ...
    log(laplace_m);
g = -0.5 + (data.^2)/2/laplace_m;
s = row_sum(map.q(1,:).*map.q(2,:).*(g.^2));
laplace_h = (get_s(prior{1}) + sum(map.q(1,:).*(data.^2)))/2/laplace_m - s;

% Plot the fits %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

inc = 0.025;
vs = inc:inc:20;
exact = struct;
exact.f = zeros(length(vs), 1);
map.f = zeros(length(vs), 1);
vb.f = zeros(length(vs), 1);
for i = 1:length(vs)
  obj = set_component(fit, 1, set_cov(density1, vs(i)));
  exact.f(i) = sum(logProb(obj, data)) + logProb(prior{1}, vs(i));
  map.f(i) = sum(logProb_bound(obj, data, map.q)) + logProb(prior{1}, vs(i));
  vb.f(i) = sum(logProb_bound(obj, data, vb.q)) + logProb(prior{1}, vs(i));
end
results = struct;
results.Exact = exact;
results.MAP = map;
results.VB = vb;
results.Laplace.f = laplace_k -0.5*laplace_h*((log(vs/laplace_m)).^2)' - log(vs');

color.Exact = 'b';
color.EP = 'c';
color.VB = 'r';
color.Laplace = 'g';
color.MAP = 'r:';
color.Hard = 'k';

figure(1),clf
algs = fieldnames(results);
legtxt = {};
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'f') && isfield(color,algs{a})
		y = exp(r.f);
		if logscale
			loglog(vs, y, color.(algs{a}));hold on;
		else
			plot(vs, y, color.(algs{a}));hold on;
		end
    legtxt{end+1} = algs{a};
  end
end
xlabel('v')
ylabel('p(v,D)')
hold off
legend(legtxt);
ax = axis;
axis([0 5 ax(3) ax(4)])
set(gca,'ytick',[])
set(gcf,'PaperUnits','inches','PaperPosition',[0.25 2.5 4 3])
print -depsc normal_v.eps

% Compute the integral approximations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

results.Exact.e = logSum(exact.f)+log(inc);
results.MAP.ehat = logSum(map.f)+log(inc);
results.MAP.e = vb_normal_v_bound(prior, m, data, map.q);
results.VB.ehat = logSum(vb.f)+log(inc);
results.VB.e = vb_normal_v_bound(prior, m, data, vb.q);
results.Laplace.ehat = logSum(results.Laplace.f)+log(inc);
results.Laplace.e = laplace_k+0.5*log(2*pi/laplace_h);

disp('Log Evidence:')
for a = 1:length(algs)
  r = results.(algs{a});
  if isfield(r,'e')
    if ~isfield(r,'ehat')
			fprintf('  %-7s = %g\n', algs{a}, r.e);
		else
			fprintf('  %-7s = %g (over entire space = %g)\n', algs{a}, r.ehat, r.e);
		end
  end
end
for a = 1:length(algs)
	r = results.(algs{a});
	if isfield(r,'e')
		fprintf('%s captures %2.0f%% of the total mass\n', algs{a}, 100*exp(r.e - results.Exact.e));
	end
end

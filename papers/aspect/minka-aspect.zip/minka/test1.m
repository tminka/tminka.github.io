N = 10;
J = 3;
K = 3;
len = 100;
alpha = [9 15 3]';
if 0
  p = dirichlet_sample([30 1 9],K);
  p = p ./ repmat(col_sum(p), K, 1);
  data = sample_doc(p, alpha, len, N);
  clear vb ep
  %save task1.mat data N J K len alpha p
else
  load task1.mat
end
if 0
  load('../LDAMLE/task2.mat')
  data = samples';
  p = beta;
  alpha = alpha';
end
[K,N] = size(data);
[K,J] = size(p);
doc = 4;
logProb_ep(p, data(:,doc), alpha)
[vb.p,vb.alpha,vb.run] = mle_vb(p, data, alpha, 0);
[ep.p,ep.alpha,ep.run] = mle_ep(p, data, alpha, 0);

compare_vb_ep

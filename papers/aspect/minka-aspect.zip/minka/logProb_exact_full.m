function e = logProb_exact_full(p, data, alpha, inc)
% Requires all alpha > 0.
% data(k,i) is n_ik
% alpha(j) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

if any(alpha == 0)
  error('must have alpha > 0');
end
if cols(alpha) == 1
  alpha = repmat(alpha, 1, cols(data));
end

[K,N] = size(data);
[K,J] = size(p);

if nargin < 4
  if J == 2
    inc = 0.02;
  else
    inc = 0.02;
    inc = 0.1;
    inc = 0.25;
  end
end
ws = ndgridmat_simplex(J, inc)';

e = -Inf*ones(1,N);
for s = 1:cols(ws)
  lambda = ws(:,s) + eps;
  
  % likelihood term
  q = log(p * lambda + eps);
  es = col_sum(data .* repmat(q, 1, N));

  % prior term
  prior = gammaln(col_sum(alpha));
  a = (alpha-1) .* repmat(log(lambda), 1, N) - gammaln(alpha);
  prior = prior + col_sum(a);
  es = es + prior;
  % es(i) = log p(x_i | lambda) p(lambda | alpha)
  
  e = logsumexp([e; es]);
end
e = sum(e) + N*(J-1)*log(inc);

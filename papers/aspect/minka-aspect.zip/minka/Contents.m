% Inference and Learning in the Generative Aspect Model.
% By Thomas P Minka (minka@stat.cmu.edu) Jun 23, 2003
%
% Inference
%   logProb_exact   - Exact log-probability of a document.
%   logProb_ep      - EP approximation for the log-prob of a document.
%   logProb_vb      - VB approximation for the log-prob of a document.
%   logProb_BIC     - BIC approximation for the log-prob of a document.
%
% Learning
%   mle_exact       - Estimate parameters using exact EM.
%   mle_ep          - Estimate parameters using EP.
%   mle_vb          - Estimate parameters using VB.
%   mle_joint       - Estimate parameters using joint max over lambda.
%   learn_alpha     - Update alpha given a Dirichlet approximation.
%   learn_p_exact   - Update p by exact EM.
%   learn_p_best    - Update p by `estimating the maximum' exactly.
%   learn_p         - Update p by `estimating the max' via Taylor expansion.
%   learn_p1        - Update p by `maximizing the estimate'.
%
% Demos
%   test_learn_p    - Compare different M-steps for p.
%   test_logProb    - Generate Figure 1
%   test_equal      - Compare VB and EP on equal aspects.
%   test_classif    - Compare VB and EP on classification.
%   test_post       - Compare VB and EP posteriors for lambda.

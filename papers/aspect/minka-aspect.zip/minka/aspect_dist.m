function d = aspect_dist(p,q)

d = sqdist(p,q);
d = sum(min(d)) + sum(min(d'));

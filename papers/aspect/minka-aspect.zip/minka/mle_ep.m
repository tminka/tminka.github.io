function [p,alpha,run] = mle_ep(p, data, alpha, learn_alpha_flag, mstep)
% MLE_EP      Estimate parameters using EP.
%
% [p,alpha,run] = MLE_EP(p,data,alpha) returns approximate maximum-likelihood
% estimates (p,alpha).  The input (p,alpha) are starting guesses.
% The estimate of p and flopcount after each iteration is stored in RUN.
%
% p = MLE_EP(p,data,alpha,0) estimates p only, leaving alpha fixed.
%
% alpha is 1 by J

if nargin < 4
  learn_alpha_flag = 1;
end
if nargin < 5
  mstep = 2;
end
show_progress = 1;

[K,N] = size(data);
[K,J] = size(p);
beta = [];
run.e = [];
run.p = {};
run.flops = [];
flops(0);
for iter = 1:150
  old_p = p;
  run.p{iter} = p;

  % approximate E-step
  if iter == 1
    niter = 300;
    niter = 30*max(col_sum(data));
  else
    % because betas are saved, we don't need as many iterations
    niter = 10;
    % safe choice
    niter = max(col_sum(data));
  end
  [run.e(iter),gamma,beta] = logProb_ep(p, data, alpha, beta, niter);
  % approximate M-step
  switch(mstep)
    case 1, p = learn_p1(data, gamma, p);
    case 2, p = learn_p(data, gamma, p);
    case 3, p = learn_p_best(data, gamma, p);
  end
  p = p ./ repmat(col_sum(p), K, 1);
  flops(flops + K*J + flops_col_sum(p));

  if learn_alpha_flag
    alpha = learn_alpha(gamma', alpha')';
  end
  
  run.flops(iter) = flops;
  
  change = max2(abs(p - old_p)/max2(p));
  fprintf('delta = %g\n',change)
  % allow interrupts
  drawnow
  if change < 1e-5
    break
  end
  
  if show_progress & rem(iter,1) == 0
    if learn_alpha_flag
      alpha'
    end
    show_trace(run,1)
    drawnow
  end
end
if show_progress
  show_trace(run,1)
end

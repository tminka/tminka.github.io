% classification test
% as described in Minka & Lafferty (2001)

% length of docs
len = 50;
% number of docs
N = 50;
% number of words
K = 5;
% number of aspects
J = 3;

alpha = ones(J,1);
if 0
p1 = (1:K)'; p1 = p1/sum(p1);
data1 = sample_doc(p1, 1, len, N);
p2 = ones(K,1)/K;
data2 = sample_doc(p2, 1, len, N);

p0 = dirichlet_sample(ones(K,1)*100,J);
disp('EP on data1')
ep.p1 = mle_ep(p0, data1, alpha, 0);
disp('EP on data2')
ep.p2 = mle_ep(p0, data2, alpha, 0);
disp('VB on data1')
vb.p1 = mle_vb(p0, data1, alpha, 0);
disp('VB on data2')
vb.p2 = mle_vb(p0, data2, alpha, 0);
% save test_classif.mat data1 data2 p1 p2 ep vb test
end
load test_classif.mat

if 0
  save_task(data1)
  save_task(test(:,i1))
  save_task(data2)
  save_task(test(:,i2))
end

test = [sample_doc(p1, 1, len, 1000) sample_doc(p2, 1, len, 1000)];
i1 = 1:1000;
i2 = i1 + 1000;
ep.class = [];
vb.class = [];
opt.class = [];
ep.like1 = 0;
ep.like2 = 0;
vb.like1 = 0;
vb.like2 = 0;
opt.like1 = 0;
opt.like2 = 0;
for i = 1:cols(test)
  if(rem(i,10) == 1) 
    fprintf('testing %d of %d\n', i, cols(test)) 
  end
  ep1 = logProb_exact_full(ep.p1, test(:,i), alpha);
  ep2 = logProb_exact_full(ep.p2, test(:,i), alpha);
  vb1 = logProb_exact_full(vb.p1, test(:,i), alpha);
  vb2 = logProb_exact_full(vb.p2, test(:,i), alpha);
  if(ep1 >= ep2) ep.class(i) = 1;
  else ep.class(i) = 2;
  end
  if(vb1 >= vb2) vb.class(i) = 1;
  else vb.class(i) = 2;
  end
  if 0
    opt1 = sum(test(:,i).*log(p1));
    opt2 = sum(test(:,i).*log(p2));
  else
    opt1 = logProb_exact_full(repmat(p1,1,J), test(:,i), alpha);
    opt2 = logProb_exact_full(repmat(p2,1,J), test(:,i), alpha);
  end
  if(opt1 >= opt2) opt.class(i) = 1;
  else opt.class(i) = 2;
  end
  if any(i == i1)
    ep.like1 = ep.like1 + ep1;
    vb.like1 = vb.like1 + vb1;
    opt.like1 = opt.like1 + opt1;
  else
    ep.like2 = ep.like2 + ep2;
    vb.like2 = vb.like2 + vb2;
    opt.like2 = opt.like2 + opt2;
  end
end
plot(ep.class)
ep.err = sum(ep.class(i1) ~= 1) + sum(ep.class(i2) ~= 2);
vb.err = sum(vb.class(i1) ~= 1) + sum(vb.class(i2) ~= 2);
opt.err = sum(opt.class(i1) ~= 1) + sum(opt.class(i2) ~= 2);
fprintf('Opt errors = %g\n',opt.err)
fprintf('EP errors = %g\n',ep.err)
fprintf('VB errors = %g\n',vb.err)
%p_lessthan(ep.err,cols(test),vb.err,cols(test))

fprintf('Opt test1 PDL = %g\n', pdl(opt.like1,test(:,i1)));
fprintf('Opt test2 PDL = %g\n', pdl(opt.like2,test(:,i2)));
fprintf('EP test1 PDL = %g\n', pdl(ep.like1,test(:,i1)));
fprintf('EP test2 PDL = %g\n', pdl(ep.like2,test(:,i2)));
fprintf('VB test1 PDL = %g\n', pdl(vb.like1,test(:,i1)));
fprintf('VB test2 PDL = %g\n', pdl(vb.like2,test(:,i2)));

function b = dirichlet_approx2(p, a, b)
% Returns a Dirichlet approximation to the data likelihood p using 
% Dirichlet prior a.

pa = sum(p.*a);
pas = pa*(1+sum(a));
m = a.*(p + pa)/pas;
m2 = (a+1).*a.*(2*p + pa)/(pas*(2+sum(a)));
b = sum(m-m2)/sum(m2-m.*m)*m - a;

J = length(p);
flops(flops + J+(J-1)+2 + 3*J + 6*J + 5*J+2*(J-1)+1);

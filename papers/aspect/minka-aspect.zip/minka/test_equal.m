% multidimensional comparison with equal aspects

% number of docs
N = 10;
% doc length
len = 100;
% number of words
K = 3;
% number of aspects
J = 3;
if 1
  p = ones(K,J)/K;
else
  p = dirichlet_sample(ones(K,1)/2,J)
end
alpha = ones(J,1);
data = sample_doc(p, alpha, len, N);
%save test7.mat data

% random initialization
p0 = dirichlet_sample(ones(K,1),J);

[ep.p,ep.alpha,ep.run] = mle_ep(p0, data, alpha, 1);
[vb.p,vb.alpha,vb.run] = mle_vb(p0, data, alpha, 1);

compare_vb_ep

function alpha = learn_alpha(gamma, alpha)
% gamma is N by J
% alpha is 1 by J

% virtual dataset
x = digamma(gamma) - repmat(digamma(row_sum(gamma)), 1, cols(gamma));
x = exp(x);
alpha = dirichlet_fit(x, alpha);

[N,J] = size(gamma);
flops(flops + N*J*(flops_digamma+1) + flops_row_sum(gamma) + N*flops_digamma);
% don't count the exp since dirichlet_fit takes log anyway

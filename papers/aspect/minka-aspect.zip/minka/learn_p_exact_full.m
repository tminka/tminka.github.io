function p = learn_p_exact_full(data, alpha, p, denom, inc)
% Requires alpha > 0.
% The result is divided by exp(denom).
% data is a single column n_k
% alpha(j) is the Dirichlet parameter for lambda_j
% p(k,j) is prob of word k in class j

[K,J] = size(p);

if nargin < 5
  if J == 2
    inc = 0.02;
  else
    inc = 0.5;
  end
end
ws = ndgridmat_simplex(J, inc)';

new_p = zeros(K,J);
for s = 1:cols(ws)
  lambda = ws(:,s) + eps;
  
  % likelihood term
  q = log(p * lambda);
  es = col_sum(data .* q);
  
  % prior term
  prior = col_sum((alpha-1) .* log(lambda));
  prior = prior + gammaln(col_sum(alpha)) - col_sum(gammaln(alpha));
  es = es + prior;
  % es = log p(x_i | lambda) p(lambda | alpha_i)
  
  q = p .* repmat(lambda', K, 1);
  r = data ./ (row_sum(q)+eps);
  q = q .* repmat(r, 1, J);
  new_p = new_p + q * exp(es - denom);
end
p = new_p * inc^(J-1);

function b = dirichlet_approx(p, a, b)
% Returns a Dirichlet approximation to the data likelihood p using 
% Dirichlet prior a.

[K,J] = size(p);
%b = ones(J,1)/10;
bar_p = digamma(a) - digamma(sum(a)+1) + p./sum(p.*a);

if 1
  for iter = 1:50
    b = inv_digamma(digamma(sum(b)+sum(a)) + bar_p) - a;
  end
  return
end

if 0
  old_b = b;
  % plot the objective
  bs = 0:0.01:2;
  e = 0;
  for i = 1:length(bs)
    b(1) = bs(i);
    e(i) = sum(gammaln(b+a)) - gammaln(sum(b) + sum(a)) - sum(bar_p.*(b+a));
  end
  plot(bs,e)
  b = old_b;
end

abort = 0;
lambda = 0.1234;
ei = 0;
for iter = 1:30
  f = digamma(b+a) - digamma(sum(b) + sum(a)) - bar_p;
  g = trigamma(b+a) - trigamma(sum(b) + sum(a));
  old_b = b;
  if(iter == 1)
    old_e = sum(gammaln(b+a)) - gammaln(sum(b) + sum(a)) - sum(bar_p.*(b+a));
  end
  while(1)
    % take a tentative step
    b = old_b - f./(g - lambda);
    if all(b+a > 0)
      e = sum(gammaln(b+a)) - gammaln(sum(b) + sum(a)) - sum(bar_p.*(b+a));
      if(e > old_e) 
	break
      else
	%fprintf('%g < %g\n', e, old_e)
      end
    end
    lambda = lambda*10;
    if(lambda > 1e+6) 
      abort = 1;
      break
    end
  end
  if abort
    disp('abort')
    break
  end
  lambda = lambda / 10;
  old_e = e;
  ei(iter) = e;
  if norm(b - old_b) < 1e-5
    break
  end
end
plot(ei)

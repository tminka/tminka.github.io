function [e,gamma] = logProb_vb(p, data, alpha, gammas)
% LOGPROB_VB      VB approximation for the log-prob of a document.
%
% LOGPROB_VB(p,data,alpha) returns the log-probability of each column of
% data under the generative aspect model with parameters (p,alpha).
% The integral over lambda is approximated using variational Bayes.
%
% data(k,i) is n_ik
% alpha(j,1) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[K,N] = size(data);
[K,J] = size(p);

e = 0;
for i = 1:N
  if nargin < 4
    % optimize gamma
    gamma = best_beta(data(:,i), alpha, p);
  else
    gamma = gammas(:,i)';
  end
  q = p .* repmat(exp(digamma(gamma)), K, 1);
  q = q ./ repmat(row_sum(q)+eps, 1, J);
  
  e = e + gammaln(sum(alpha)) - gammaln(sum(gamma));
  e = e + sum(gammaln(gamma)) - sum(gammaln(alpha));

  r = log((p+eps) ./ (q+eps));
  e = e + sum(data(:,i) .* row_sum(q .* r));
end

function p = approx1_dirichlet_m_p(data, alpha, p)
% this is a first order approximation using E[log(lambda)]
% only one EM iteration is performed.
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[K,N] = size(data);
[K,J] = size(p);

new_p = zeros(K,J);
for i = 1:N
  lambda = exp(digamma(alpha(:,i)))';
  %lambda = alpha(:,i)';
  q = p .* repmat(lambda, K, 1);
  r = data(:,i) ./ (row_sum(q)+eps);
  qi = q .* repmat(r, 1, J);
  % qi(k,j) = n_ik p(j | k, i)
  new_p = new_p + qi;
end
p = new_p;

flops(flops + N*(2*J*flops_exp + J*K + flops_row_sum(q) + K + 2*J*K));

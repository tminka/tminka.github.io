function data = sample_doc(p, alpha, doc_size, n)

if cols(alpha) == 1
  alpha = repmat(alpha, 1, n);
end

data = [];
for i = 1:n
  lambda = dirichlet_sample(alpha(:,i));
  q = p * lambda;
  doc = sample_hist(q, doc_size);
  data = [data doc];
end

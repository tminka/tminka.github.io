data = [10 20 30]';
alpha = [9 15 3];
alpha = [1 1 1];
p = [1 1 1; 1 2 3; 6 5 4]';
p = p ./ repmat(col_sum(p), 3, 1);
best_beta(data, alpha, p)
beta = [1 1 1];
best_beta(data, alpha, p, beta, 7)

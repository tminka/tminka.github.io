function e = marginal_likelihood_fcn(p, data, alpha)

[K,N] = size(data);
[J,N] = size(alpha);
p = reshape(p, K, J);
p = clip(p);
p = p ./ repmat(col_sum(p)+eps, K, 1);
e = -marginal_likelihood(p, data, alpha);

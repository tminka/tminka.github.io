function u = unit(i, n)

u = zeros(n, 1);
u(i) = 1;

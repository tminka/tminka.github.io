#include "mex.h"
#include "math.h"

/* Modifies q to be the bound parameters at lambda. 
 * This uses the EM bound.
 */
void bound1(int J, int K, double *lambda, double *p, double *q)
{
  int j,k;
  for(k=0;k<K;k++) {
    double sum_q = 0;
    for(j=0;j<J;j++) {
      q[j*K] = p[j*K] * lambda[j];
      sum_q += q[j*K];
    }
    for(j=0;j<J;j++) {
      q[j*K] /= sum_q;
    }
    /* advance to the next k */
    p++;
    q++;
  }
}

/* This uses the new bound. 
 * It requires lambda to be non-binary.
 */
void bound2(int J, int K, double *lambda, double *p, double *q)
{
  int j,k;
  for(k=0;k<K;k++) {
    double sum_q = 0;
    int minj = 0;
    double minp = 2;
    for(j=0;j<J;j++) {
      q[j*K] = p[j*K] * lambda[j];
      sum_q += q[j*K];
      if((p[j*K] < minp) && (lambda[j] > 0)) {
	minp = p[j*K];
	minj = j;
      }
    }
    for(j=0;j<J;j++) {
      q[j*K] -= minp * lambda[j];
      if(sum_q > 0) {
	q[j*K] /= sum_q;
      }
    }
    /* advance to the next k */
    p++;
    q++;
  }
}

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  int K, J;
  int iter, j, k;
  double *data, *alpha, *p, *lambda, *old_lambda, *q;
  if(nrhs < 3) {
    mexErrMsgTxt("Usage: best_lambda(data, alpha, p)");
  }
  data = mxGetPr(prhs[0]);
  alpha = mxGetPr(prhs[1]);
  p = mxGetPr(prhs[2]);
  K = mxGetM(prhs[2]);
  J = mxGetN(prhs[2]);
  plhs[0] = mxCreateDoubleMatrix(1, J, mxREAL);
  lambda = mxGetPr(plhs[0]);
  if(nrhs == 4) {
    /* initialize with the fourth argument */
    memcpy(lambda, mxGetPr(prhs[3]), J*sizeof(double));
  }
  else {
    for(j=0;j<J;j++) lambda[j] = 1.0/J;
  }
  old_lambda = mxCalloc(J, sizeof(double));
  /* K is the minor dimension of q */
  q = mxCalloc(J*K, sizeof(double));

  for(iter=0;iter<100;iter++) {
    double sum_lambda = 0, *qptr, max_change = 0;
    /* check for binary lambda */
    if(1) {
      int nonzero=0;
      for(j=0;j<J;j++) {
	if(lambda[j] > 0) nonzero++;
      }
      /* is lambda binary? */
      if(nonzero == 1) break;
    }
    memcpy(old_lambda, lambda, J*sizeof(double));
    bound2(J, K, lambda, p, q);
    qptr = q;
    for(j=0;j<J;j++) {
      if(alpha[j] > 0) {
	double sum = 0;
	for(k=0;k<K;k++) {
	  sum += data[k] * (*qptr++);
	}
	lambda[j] = sum + alpha[j] - 1;
	if(lambda[j] < 0) lambda[j] = 0;
	sum_lambda += lambda[j];
      }
      else {
	lambda[j] = 0;
	qptr += K;
      }
    }
    if(sum_lambda == 0) {
      /* The bound is perfectly flat so lambda is determined by the prior. */
      /* Determine how many alphas are greater than 1 or equal to 1. */
      int greater = 0, equal = 0, maxj;
      double max_alpha = -1;
      for(j=0;j<J;j++) {
	if(alpha[j] > 1) greater++;
	if(alpha[j] == 1) equal++;
	if(alpha[j] > max_alpha) {
	  max_alpha = alpha[j];
	  maxj = j;
	}
      }
      if(greater) {
	/* lambda[j]'s with alpha[j] <= 1 are zero. */
	sum_lambda = 0;
	for(j=0;j<J;j++) {
	  lambda[j] = (alpha[j] > 1) ? (alpha[j]-1) : 0;
	  sum_lambda += lambda[j];
	}
	for(j=0;j<J;j++) {
	  lambda[j] /= sum_lambda;
	}
      }
      else if(equal) {
	/* None are greater but some are equal to 1. */
	for(j=0;j<J;j++) {
	  lambda[j] = (alpha[j] == 1) ? 1.0/equal : 0;
	}
      }
      else {
	/* All are less than 1. The optimal lambda is binary. */
	for(j=0;j<J;j++) {
	  lambda[j] = (j == maxj) ? 1 : 0;
	}
      }
      break;
    }
    for(j=0;j<J;j++) {
      double change;
      lambda[j] /= sum_lambda;
#if 0
      printf("lambda[%d] = %g\n", j, lambda[j]);
#endif
      change = fabs(lambda[j] - old_lambda[j]);
      if(change > max_change) max_change = change;
    }
    /* has anything changed? */
    if(max_change < 1e-10) break;
  }
#if 0
  printf("iter = %d\n", iter);
#endif
}

% view the posterior for p
% generates Figure 1 in Minka & Lafferty (2002)
% (with a resampled dataset)

%p = [1/4 3/4; 1/2 1/2]';
%p = [1/2 1/2; 1/2 1/2]';
p = [1/2 1/2; 1-1e-4 1e-4]';
[K,J] = size(p);
N = 10;
len = 10;

alpha = [1 1]';
clear le pmax
data = sample_doc(p, alpha, len, N)

ps = linspace(0,1,20);
for i = 1:length(ps)
  fprintf('%d of %d\n',i,length(ps));
  drawnow
  ip = p;
  ip(:,1) = [ps(i); 1-ps(i)];
  le(i,1) = logProb_exact(ip, data, alpha);
  le(i,2) = logProb_BIC(ip, data, alpha);
  le(i,3) = logProb_vb(ip, data, alpha);
  le(i,4) = logProb_ep(ip, data, alpha);
end
e = exp(le - repmat(logsumexp(le), rows(le), 1));

if 1
  %p0 = dirichlet_sample(ones(K,1)/K,J);
  p0 = p;
  p0(:,1) = dirichlet_sample(alpha);
  pm = mle_vb(p0, data, alpha, 0, 1);
  pmax(1) = pm(1,1);
  pm = mle_vb(p0, data, alpha, 0, 2);
  pmax(3) = pm(1,1);
  pm = mle_ep(p0, data, alpha, 0, 2);
  pmax(2) = pm(1,1);
  %pm = mle_ep(p0, data, alpha, 0, 1);
  %pmax(4) = pm(1,1);
end

figure(1)
clf
plot(ps, e(:,1), '-', ps, e(:,2), '--')
legend('Exact', 'Max')
xlabel('p(w=1|a=1)')
ylabel('likelihood')
set(gcf,'paperpos',[0.25 2.5 4 2])
set(gca,'ytick',[])

for i = 1:cols(data)
  p_hat = data(1,i)/(data(1,i)+data(2,i));
  v = axis;
  line([p_hat p_hat], [v(3) v(4)], 'Color', 'red', 'LineStyle', ':')
end

figure(2)
clf
plot(ps, e(:,1), '-', ps, e(:,3), '--', ps, e(:,4), '-.')
if exist('pmax')
  v = axis;
  line([pmax(1) pmax(1)], [v(3) v(4)], 'Color', 'green', 'LineStyle', '--')
  line([pmax(3) pmax(3)], [v(3) v(4)], 'Color', 'yellow', 'LineStyle', '-')
  line([pmax(2) pmax(2)], [v(3) v(4)], 'Color', 'red', 'LineStyle', '-.')
  %line([pmax(4) pmax(4)], [v(3) v(4)], 'Color', 'magenta', 'LineStyle', '-.')
end
legend('Exact', 'VB', 'EP')
xlabel('p(w=1|a=1)')
ylabel('likelihood')
set(gcf,'paperpos',[0.25 2.5 4 2])
set(gca,'ytick',[])


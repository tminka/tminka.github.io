function e = marginal_likelihood_mc(p, data, alpha, inc)

p = dirichlet_sample();

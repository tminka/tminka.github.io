function [p,alpha,run] = mle_vb(p, data, alpha, learn_alpha_flag, mstep)
% MLE_VB      Estimate parameters using VB.
%
% [p,alpha,run] = MLE_VB(p,data,alpha) returns approximate maximum-likelihood
% estimates (p,alpha).  The input (p,alpha) are starting guesses.
% The estimate of p and flopcount after each iteration is stored in RUN.
%
% p = MLE_VB(p,data,alpha,0) estimates p only, leaving alpha fixed.
% [...] = MLE_VB(p,data,alpha,learn_alpha,2) uses the better M-step.

if nargin < 4
  % learn alpha by default
  learn_alpha_flag = 1;
end
if nargin < 5
  mstep = 1;
end
show_progress = 1;

[K,N] = size(data);
[K,J] = size(p);
beta = ones(N,J);
run.p = {};
run.e = [];
run.flops = [];
flops(0);
for iter = 1:1000
  old_p = p;
  run.p{iter} = p;

  % approximate E-step
  % run the EM loop for beta twice as often as for p
  if iter == 1
    niter = 100;
  else
    niter = 2;
  end
  for i = 1:N
    beta(i,:) = best_beta(data(:,i), alpha, p, beta(i,:), niter);
  end
  % beta(i,j) is the Dirichlet parameter for lambda_ij
  
  % approximate M-step
  switch(mstep)
    case 1, p = learn_p1(data, beta', p);
    case 2, p = learn_p(data, beta', p);
    case 3, p = learn_p_best(data, beta', p);
  end
  p = p ./ repmat(col_sum(p), K, 1);
  flops(flops + K*J + flops_col_sum(p));

  if learn_alpha_flag
    alpha = learn_alpha(beta, alpha')';
  end
  
  run.flops(iter) = flops;
  
  if show_progress
    fl = flops;
    run.e(iter) = logProb_vb(p, data, alpha, beta');
    flops(fl);
  end

  [change,i,j] = max2(abs(p - old_p)/max2(p));
  %fprintf('delta = %g for p(%g,%g) = %g\n', change, i, j, p(i,j))
  % allow interrupts
  drawnow
  if change < 1e-5
    break
  end
  
  if show_progress & rem(iter,100) == 0
    if learn_alpha_flag
      alpha'
    end
    show_trace(run,1)
    drawnow
  end
end
if show_progress 
  show_trace(run,1)
end

function e = logProb_BIC(p, data, alpha, lambdas)
% LOGPROB_BIC    BIC approximation for the log-prob of a document.
%
% LOGPROB_BIC(p,data,alpha) returns the log-probability of each column of
% data under the generative aspect model with parameters (p,alpha).
% The integral over lambda is approximated by its maximum, plus a BIC
% penalty term.
%
% p(k,j) is prob of word k in class j
% alpha is a column

[K,J] = size(p);
e = 0;
for i = 1:cols(data)
  if nargin < 4
    % find the best lambda
    lambda = best_lambda(data(:,i), alpha', p);
  else
    lambda = lambdas(i,:);
  end
  e = e + logProb_joint(p, lambda, data(:,i), alpha);
  % BIC correction
  e = e + (J-1)/2*log(2*pi/sum(data(:,i)));
end

function e = pdl(like, data)
% partial description length

[K,N] = size(data);
p = data./repmat(sum(data),K,1);
if 0
  e = mean(sum(p.*log(p+eps)));
  e = -like/sum(sum(data)) + e;
else
  e = sum(sum(data.*log(p+eps)));
  e = (-like + e)/cols(data)/log(2);
end

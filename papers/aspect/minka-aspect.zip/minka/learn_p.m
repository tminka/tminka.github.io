function p = approx3_dirichlet_m_p(data, alpha, p)
% This is a second-order approximation about E[lambda].
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[J,N] = size(alpha);
[K,J] = size(p);

new_p = zeros(K,J);
for i = 1:N
  sum_alpha = sum(alpha(:,i));
  for j = find(alpha(:,i) > 0)'
    % m(j) = 0 for j's with alpha = 0, so they won't count
    m = (alpha(:,i)+unit(j,J)) ./ (sum_alpha + 1);
  
    s = p * m + eps;
    % s(k) = sum_j p_j(k) m_j
    s2 = (p.^2) * m;
    % s2(k) = sum_j p_j(k)^2 m_j
    ei = 1 + (s2./s.^2 - 1)/(sum_alpha + 2);
    ei = ei ./ s .* p(:,j) * (alpha(j,i)/sum_alpha);
    
    new_p(:,j) = new_p(:,j) + ei .* data(:,i);
  end
end
p = new_p;

flops(flops + N*(J-1+J*(2+J+2*flops_mul(K,J,1)+K*J+5*K+3*K+1+2*K)));

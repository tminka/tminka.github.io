function x = ndgridmat_simplex(d, inc, invalid)
% NDGRIDMAT_SIMPLEX(d,inc,invalid) returns all lattice points in the 
% d-dimensional simplex, as rows of x.
% row_sum(x) = 1.
% invalid is the value to use for invalid points.
% use invalid = [] to remove invalid points (default).
%
% example:
% x = ndgridmat_simplex(3,0.1); plot(x(:,1),x(:,2),'.');

if nargin < 3
  invalid = [];
end
c = xrepmat({0:inc:1}, 1, d-1);
x = ndgridmat(c{:});
x = [x 1-row_sum(x)];
i = find(x(:,d) < 0);
if ~isempty(i)
  % old versions of matlab require a special case
  if isempty(invalid)
    x(i,:) = [];
  else
    x(i,:) = invalid;
  end
end


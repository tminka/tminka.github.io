function [lambda, p] = mle_joint(p, data, alpha)
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[K,N] = size(data);
[K,J] = size(p);
lambda = ones(N,J)/J;
loo = 0;
loo_p = zeros(K*J, N);
for iter = 1:50
  old_lambda = lambda;
  old_p = p;
  
  new_p = zeros(K,J);
  for i = 1:cols(data)
    if loo & iter > 1
      % construct a p matrix which leaves out i
      p = old_new_p - reshape(loo_p(:,i), K, J);
      p = p ./ repmat(col_sum(p)+eps, K, 1);
    end
    lambda(i,:) = best_lambda(data(:,i), alpha(:,i)', p, lambda(i,:));
    % E-step
    q = p .* repmat(lambda(i,:), K, 1);
    q = q ./ repmat(row_sum(q)+eps, 1, J);
    % q(k,j) = p(j | k, i)
    ip = q .* repmat(data(:,i), 1, J);
    new_p = new_p + ip;
    if loo
      loo_p(:, i) = vec(ip);
    end
  end
  old_new_p = new_p;
  p = new_p ./ repmat(col_sum(new_p)+eps, K, 1);

  if 0 & rem(iter, 5) == 0
    % fit new alphas
    % path(path, '/home/minka/matlab/density')
    case_size = [3 20 20];
    base = 1;
    for c = 1:length(case_size)
      r = base:(base+case_size(c)-1);
      ind = find(alpha(:, base) > 0);
      c_lambda = lambda(r, ind)';
      obj = dirichlet_density(alpha(ind, base));
      obj = train(obj, c_lambda);
      disp(obj)
      alpha(ind, r) = repmat(get_a(obj), 1, case_size(c));
      base = base + case_size(c);
    end
  end
  
  e(iter) = logProb_joint(p, lambda, data, alpha);
  %e(iter) = bic_likelihood(p, data, alpha);
  f(iter) = logProb_BIC(p, data, alpha);
  
  change_lambda = max(max(abs(lambda - old_lambda)));
  change_p = max(max(abs(p - old_p)));
  change = max([change_lambda change_p]);
  if change < 1e-6
    break
  end
  
  if rem(iter,5) == 0
    p
    figure(2)
    subplot(2,1,1)
    plot(e)
    title('joint likelihood')
    subplot(2,1,2)
    plot(f)
    title('marginal likelihood')
    drawnow
  end
end
figure(2)
subplot(2,1,1)
plot(e)
title('joint likelihood')
subplot(2,1,2)
plot(f)
title('marginal likelihood')

function e = logProb_exact(p, data, alpha)
% LOGPROB_EXACT   Exact log-probability of a document.
%
% LOGPROB_EXACT(p,data,alpha) returns the log-probability of each column of
% data under the generative aspect model with parameters (p,alpha).
%
% data(k,i) is n_ik
% alpha(j,1) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

if cols(alpha) == 1
  alpha = repmat(alpha, 1, cols(data));
end
active = (alpha > 0);
e = 0;
while(cols(active) > 0)
  % collect the indices of all documents with the same label vector
  i = 1;
  for j = 2:cols(active)
    if all(active(:,j) == active(:,1))
      i = [i j];
    end
  end
  % restrict alpha and p to the active labels
  ind = find(active(:,1));
  e = e + logProb_exact_full(p(:,ind), data(:,i), alpha(ind,i));
  % remove these documents from the list
  active(:,i) = [];
  alpha(:,i) = [];
  data(:,i) = [];
end

function save_task(data,p0)

fid = fopen('docs.txt','w');
[K,N] = size(data);
for doc = 1:N
  fprintf(fid,'<DOC %d>\n', doc);
  for k = 1:K
    len = data(k,doc);
    for i = 1:len
      fprintf(fid,'%c\n','A'-1+k);
    end
  end
  fprintf(fid,'</DOC>\n');
end
fclose(fid);
if nargin >= 2
  save aspects.txt p0 -ascii
end

function lambda = best_lambda(data, alpha, p, lambda)
% alpha is 1 by J

[K,J] = size(p);
if nargin < 4
  lambda = ones(1,J)/J;
end
for iter = 1:100
  old_lambda = lambda;
  
  % E-step
  q = p .* repmat(lambda, K, 1);
  q = q ./ repmat(row_sum(q)+eps, 1, J);
  %q = dirichlet_e_em_lambda(lambda, p);
  % q(k,j) = p(k,j)*lambda(j)/sum_j
  
  % M-step
  lambda = (data' * q) + alpha - 1;
  lambda(find(alpha == 0)) = 0;
  lambda = lambda / sum(lambda);

  if max(abs(lambda - old_lambda)) < 1e-10
    break
  end
end

function p = learn_p_exact(data, alpha, p, varargin)
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[K,J] = size(p);

new_p = zeros(K,J);
for i = 1:cols(data)
  ind = find(alpha(:,i) > 0);
  p_ind = p(:,ind);
  denom = logProb_exact_full(p_ind, data(:,i), alpha(ind,i), varargin{:});
  ip = learn_p_exact_full(data(:,i), alpha(ind,i), p_ind, denom, varargin{:});
  new_p(:,ind) = new_p(:,ind) + ip;
end
p = new_p;

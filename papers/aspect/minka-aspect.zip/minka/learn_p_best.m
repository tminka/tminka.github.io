function p = learn_p_best(data, alpha, p)
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in class j

[K,N] = size(alpha);
[K,J] = size(p);

if J == 2
  % optimized for 2 aspects
  inc = 1e-4;
  lambda = 0:inc:(1-inc);
  lambda = lambda';

  prior = zeros(length(lambda), N);
  z = gammaln(col_sum(alpha)) - col_sum(gammaln(alpha));
  for i = 1:N
    prior(:,i) = (alpha(1,i)-1)*log(lambda+eps) ...
	+ (alpha(2,i)-1)*log(1-lambda+eps) + z(i);
  end
  % prior(s, i) = log q_i(lambda(s))
  prior = exp(prior)*data';
  % prior(s, k) = sum_i n_ik q_i(lambda(s))
  
  new_p = zeros(K,J);
  for k = 1:K
    q = [p(k,1)*lambda p(k,2)*(1-lambda)];
    if 1
      q = q ./ repmat(row_sum(q), 1, J);
      q = q .* repmat(prior(:,k), 1, J);
      q = col_sum(q)*inc;
    else
      q = log(q+eps);
      q = q - repmat(logsumexp(q,2), 1, J);
      q = q + repmat(log(prior(:,k)), 1, J);
      q = exp(logsumexp(q) + log(inc));
    end
    new_p(k,:) = q;
  end
  p = new_p;
  return
end

% J > 2
inc = 1e-4;
ws = ndgridmat_simplex(J, inc)';

e = -Inf*ones(K,J);
e = e(:);
for s = 1:cols(ws)
  lambda = ws(:,s);

  prior = col_sum((alpha-1) .* repmat(log(lambda+eps), 1, N));
  prior = prior + gammaln(col_sum(alpha)) - col_sum(gammaln(alpha));
  % prior(i) = log q_i(lambda)
  prior = data*exp(prior)';
  % prior(k) = sum_i n_ik q_i(lambda)
  prior = log(prior);
  
  es = p .* repmat(lambda', K, 1);
  es = log(es+eps);
  es = es - repmat(logsumexp(es,2), 1, J);
  % es(k,j) = q_k(j | lambda)
  es = es + repmat(prior, 1, J);

  e = logsumexp([e es(:)],2);
end
p = exp(e + (J-1)*log(inc));
p = reshape(p,K,J);

function e = joint_likelihood(p, lambda, data, alpha)
% p(k,j) is prob of word k in class j
% lambda(i,j) is mixing weight for class j in document i
% data(k,i) is n_ik
% alpha(j,i) is the Dirichlet parameter for lambda_ij

% likelihood
q = log((p * lambda') + eps);
e = sum(sum(data .* q));
% prior
e = e + sum(gammaln(col_sum(alpha)));
% set zeros to 1 so they don't count
alpha(find(alpha == 0)) = 1;
a = (alpha-1) .* log(lambda+eps)' - gammaln(alpha);
e = e + sum(sum(a));

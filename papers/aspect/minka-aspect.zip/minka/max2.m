function [v, i, j] = max2(x)

[v,i] = max(x);
[v,j] = max(v);
i = i(j);

function show_trace(run,a)

if nargin < 2
  a = 1;
end

figure(2), clf
plot(run.e)
xlabel('Iteration')
ylabel('Likelihood')

% figure 1 has evolution of aspect a probs
figure(1), clf
K = rows(run.p{1});
f = [];
for k = 1:K
  for iter = 1:length(run.p)
    p = run.p{iter};
    f(k,iter) = p(k,a);
  end
end
plot(f')
xlabel('Iteration')
ylabel('P(w) for Aspect 1')

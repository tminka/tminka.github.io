% compare M-steps
% p2 is usually better than p1

data = ones(2,1);
alpha = ones(2,1);
p = [1/3 2/3; 1/2 1/2]';
pe = learn_p_exact(data, alpha, p);
pb = learn_p_best(data, alpha, p);
p1 = learn_p1(data, alpha, p);
p2 = learn_p(data, alpha, p);
fprintf('pb error = %g\n', norm(pb-pe))
fprintf('p1 error = %g\n', norm(p1-pe))
fprintf('p2 error = %g\n', norm(p2-pe))

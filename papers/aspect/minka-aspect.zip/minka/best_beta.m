function beta = best_beta(data, alpha, p, beta, niter)
% data is K by 1
% alpha is a vector of length J
% beta is 1 by J

% remove irrelevant dimensions
total_J = cols(p);
ind = find(alpha > 0);
alpha = alpha(ind);
p = p(:,ind);

[K,J] = size(p);
if nargin < 4
  beta = ones(1,J);
else
  beta = beta(ind);
end
if nargin < 5
  niter = 1000;
end
if cols(alpha) == 1
  alpha = alpha';
end
for iter = 1:niter
  old_beta = beta;
  % E-step
  lambda = exp(digamma(beta));
  q = p .* repmat(lambda, K, 1);
  q = q ./ repmat(row_sum(q)+eps, 1, J);
  % q is K by J
  % M-step
  beta = (data' * q) + alpha;
  
  if max(abs(beta - old_beta)) < 1e-10
    break
  end
end
% assume flops_digamma = flops_exp
flops(flops + iter*(2*J*flops_exp + 2*J*K + flops_row_sum(q) + ...
    flops_mul(1,K,J) + J));

% put irrelevant dimensions back
beta_short = beta;
beta = zeros(1,total_J);
beta(ind) = beta_short;

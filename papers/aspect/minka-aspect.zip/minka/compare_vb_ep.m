% make plots to compare vb and ep runs on a dataset.
% requires the following variables to be defined: data, p, ep, vb

if 1
  figure(1), clf
  plot(p(1,:),p(2,:),'ok');
  hold on
  plot(ep.p(1,:),ep.p(2,:),'ob');
  plot(vb.p(1,:),vb.p(2,:),'xg');
  n = data./repmat(col_sum(data), rows(data), 1);
  plot(n(1,:),n(2,:),'.b')
  line([0 1], [1 0], 'Color', 'black')
  legend('True','EP','VB','Data')
  xlabel('p(w=1|a)')
  ylabel('p(w=2|a)')
  set(gcf,'paperpos',[0.25 2.5 3.5 3.5])
  %print -dpng aspect1.png
end

if isfield(ep,'run')
  % accuracy curves
  ep.acc = [];
  for i = 1:length(ep.run.p)
    ep.acc(i) = aspect_dist(p,ep.run.p{i});
  end
  vb.acc = [];
  for i = 1:length(vb.run.p)
    vb.acc(i) = aspect_dist(p,vb.run.p{i});
  end
  figure(2)
  loglog(ep.run.flops, ep.acc, '-', vb.run.flops, vb.acc, '-g')
  axis_pct
  xlabel('FLOPS')
  ylabel('Error')
  legend('EP','VB',4)
end

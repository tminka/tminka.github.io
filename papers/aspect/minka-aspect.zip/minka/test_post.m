% compare the approximate posterior q(lambda) for VB vs EP

p = [0.7 0.3];
p = [p; 1-p];
data = [4 6]'*100;
alpha = [1 1];
lambda1 = linspace(0,1,400);
lambda = [lambda1; 1-lambda1];
exact.f = 1;
for w = 1:length(data)
  exact.f = exact.f .* (p(w,:)*lambda).^data(w);
end

[e,gamma] = logProb_vb(p, data, alpha);
e = e - (gammaln(sum(alpha)) - sum(gammaln(alpha)));
e = e - (sum(gammaln(gamma)) - gammaln(sum(gamma)));
gamma = gamma-alpha;
vb.f = exp(gamma*log(lambda+eps) + e);

[e,gamma] = logProb_ep(p, data, alpha', [], 1e6);
e = e - (gammaln(sum(alpha)) - sum(gammaln(alpha)));
e = e - (sum(gammaln(gamma)) - gammaln(sum(gamma)));
gamma = gamma'-alpha;
ep.f = exp(gamma*log(lambda+eps) + e);

figure(1)
clf
plot(lambda1,exact.f, '-', ...
    lambda1, vb.f, '-', ...
    lambda1, ep.f, '-')
legend('Exact','VB','EP',1)
xlabel('\lambda')
ylabel('q(\lambda)')
set(gca,'ytick',[])
set(gcf,'paperpos',[0.25 2.5 5 4])
% print -dpng one_term.png

% compare moments
exact.m = sum(exact.f .* lambda1)/sum(exact.f);
exact.v = sum(exact.f .* lambda1.^2)/sum(exact.f) - exact.m^2;
ep.m = sum(ep.f .* lambda1)/sum(ep.f);
ep.v = sum(ep.f .* lambda1.^2)/sum(ep.f) - ep.m^2;
vb.m = sum(vb.f .* lambda1)/sum(vb.f);
vb.v = sum(vb.f .* lambda1.^2)/sum(vb.f) - vb.m^2;
fprintf('exact mean = %g\n', exact.m);
fprintf('exact variance = %g\n', exact.v);
fprintf('ep mean = %g (error = %g)\n', ep.m, abs(ep.m-exact.m));
fprintf('ep var = %g (error = %g)\n', ep.v, abs(ep.v-exact.v));
fprintf('vb mean = %g (error = %g)\n', vb.m, abs(vb.m-exact.m));
fprintf('vb var = %g (error = %g)\n', vb.v, abs(vb.v-exact.v));

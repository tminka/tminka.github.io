function e = perplexity(like, data)

e = exp(-like/sum(sum(data)));

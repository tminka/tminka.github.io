/* mex('best_beta.c',[getenv('HOME') '\matlab\lightspeed\util.obj']);
 */
#include "mex.h"
#include <math.h>
extern double digamma(double);

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  int K, J;
  int iter, niter, j, k;
  double max_change;
  double *data, *alpha, *p, *beta, *old_beta, *q;
  if(nrhs < 3) {
    mexErrMsgTxt("Usage: best_beta(data, alpha, p)");
  }
  data = mxGetPr(prhs[0]);
  alpha = mxGetPr(prhs[1]);
  p = mxGetPr(prhs[2]);
  K = mxGetM(prhs[2]);
  J = mxGetN(prhs[2]);
  plhs[0] = mxCreateDoubleMatrix(1, J, mxREAL);
  beta = mxGetPr(plhs[0]);
  if(nrhs >= 4) {
    /* initialize with the fourth argument */
    memcpy(beta, mxGetPr(prhs[3]), J*sizeof(double));
  }
  else {
    for(j=0;j<J;j++) beta[j] = 1.0;
  }
  if(nrhs >= 5) {
    niter = *mxGetPr(prhs[4]);
  }
  else niter = 1000;
  old_beta = mxCalloc(J, sizeof(double));
  /* K is the minor dimension of q */
  q = mxCalloc(J*K, sizeof(double));
  
  for(iter=0;iter<niter;iter++) {
    memcpy(old_beta, beta, J*sizeof(double));

    /* E-step */
    for(j=0;j<J;j++) {
      double lambda = exp(digamma(beta[j]));
      for(k=0;k<K;k++) {
	q[k + j*K] = p[k + j*K] * lambda;
      }
    }
    /* normalize */
    for(k=0;k<K;k++) {
      double sum = 0;
      for(j=0;j<J;j++) {
	sum += q[k + j*K];
      }
      for(j=0;j<J;j++) {
	q[k + j*K] /= sum;
      }
    }

    /* M-step */
    for(j=0;j<J;j++) {
      double sum = 0;
      for(k=0;k<K;k++) {
	sum += data[k] * q[k + j*K];
      }
      beta[j] = sum + alpha[j];
    }
    max_change = 0;
    for(j=0;j<J;j++) {
      double change = fabs(beta[j] - old_beta[j]);
      if(change > max_change) max_change = change;
#if 0
      printf("beta[%d] = %g\n", j, beta[j]);
#endif
    }
    /* has anything changed? */
    if(max_change < 1e-10) break;
  }
#if 0
  printf("iter = %d\n", iter);
#endif
}

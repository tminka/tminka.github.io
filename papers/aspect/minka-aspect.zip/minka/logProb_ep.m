function [e,gamma,beta] = logProb_ep(p, data, alpha, beta, niter)
% LOGPROB_EP      EP approximation for the log-prob of a document.
%
% LOGPROB_EP(p,data,alpha) returns the log-probability of each column of
% data under the generative aspect model with parameters (p,alpha).
% The integral over lambda is approximated using Expectation-Propagation.
%
% [e,gamma,beta] = LOGPROB_EP(...) also returns an approximate Dirichlet 
% posterior (gamma) for each document.  beta is the final EP parameters.
%
% data(k,i) is n_ik
% alpha(j,1) is the Dirichlet parameter for lambda_ij
% p(k,j) is prob of word k in aspect j
% gamma is J by N

[K,N] = size(data);
[K,J] = size(p);

if nargin < 4 | length(beta) == 0
  beta = {};
  for doc = 1:N
    beta{doc} = zeros(J,K);
  end
end
gamma = [];

if nargin < 5
  niter = 100;
end
e = zeros(1,N);
for doc = 1:N
  % b(a,w) is the beta for word w divided by n_w (beta for one occurrence)
  %b = zeros(J,K);
  b = beta{doc};
  a = row_sum(scale_cols(b,data(:,doc))) + alpha;
  flops(flops + flops_row_sum(b) + J*K + J);
  s = zeros(1,K);
  last = 0;
  for iter = 1:niter
    old_b = b;
    skip = 0;
    last = last | (iter == niter);
    % rem1_likelihood is faster because it is vectorized over words
    for i = 1:K
      if(data(i,doc) == 0) 
	continue
      end
      w = i;
      %a0 = row_sum(scale_cols(b,data(:,doc))) - b(:,i) + alpha;
      a0 = a - b(:,i);
      flops(flops + J);
      if(any(a0 < 0)) 
	skip = skip+1;
	%error('cannot delete')
	continue
      end
      if 1
	newb = dirichlet_approx2(p(w,:)', a0, b(:,i));
      else
	% inline dirichlet_approx2
	pa = sum(p(w,:)'.*a0);
	pas = pa*(1+sum(a0));
	m = a0.*(p(w,:)'+pa)/pas;
	m2 = (a0+1).*a0.*(2*p(w,:)'+pa)/(pas*(2+sum(a0)));
	newb = sum(m-m2)/sum(m2-m.*m)*m - a0;
	% no flopcount
      end
      step = 1/data(w,doc);
      newb = step*newb + (1-step)*b(:,i);
      newa = a + (newb - b(:,i))*data(w,doc);
      flops(flops + 2 + 3*J + 3*J);
      if(any(newa < 0))
	%fprintf('skipping word %d\n',w)
	skip = skip+1;
	continue
      end
      a = newa;
      b(:,i) = newb;
      ab = a + b(:,i);
      if last & all(ab > 0)
	% the true integral
	s(i) = sum(gammaln(a)) - gammaln(sum(a)) + log(sum(a.*p(w,:)')/sum(a));
	% minus the false integral
	s(i) = s(i) - sum(gammaln(ab)) + gammaln(sum(ab));
	s(i) = s(i)*data(w,doc);
      end
    end
    if(skip > 0) 
      fprintf('skipped %d on iter %d\n',skip,iter)
    end
    %a = row_sum(scale_cols(b,data(:,doc))) + alpha;

    if last
      % the normalizing term for the prior
      ed = gammaln(sum(alpha)) - sum(gammaln(alpha));
      % the integral of the approx
      ed = ed + sum(s) + sum(gammaln(a)) - gammaln(sum(a));
      e(doc) = ed;
    end
  
    if max(abs(b - old_b)) < 1e-5 & skip == 0
      if last
	break
      else
	last = 1;
      end
    end
  end
  % flops for the normalizing constant
  flops(flops + K*(3*(J-1) + 2*(1+J)*flops_exp + J+1 + flops_exp + J+1 + 5));
  flops(flops + 2*(J-1) + 2*(1+J)*flops_exp + K-1 + 4);
  if skip > 0
    %error('BEP failed to converge') % on doc %d\n',doc)
  elseif iter > 100
    fprintf('EP: %d iters\n', iter)
  end
  beta{doc} = b;
  gamma(:,doc) = a;
end
e = sum(e);

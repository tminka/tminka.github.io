function p = marginal_max_exact(p, data, alpha)

[K,N] = size(data);
[K,J] = size(p);
for iter = 1:100
  old_p = p;

  inc = 0.5/iter;
  p = exact_m_p(data, alpha, p, inc);
  p = p ./ repmat(col_sum(p), K, 1)
  
  e(iter) = bic_likelihood(p, data, alpha);
  f(iter) = marginal_likelihood(p, data, alpha);
  
  change = max(max(abs(p - old_p)));
  if change < 1e-4
    break
  end
  
  if rem(iter,5) == 0
    figure(2)
    subplot(2,1,1)
    plot(e)
    title('BIC likelihood')
    subplot(2,1,2)
    plot(f)
    title('Marginal likelihood')
    drawnow
  end
end
figure(2)
subplot(2,1,1)
plot(e)
title('BIC likelihood')
subplot(2,1,2)
plot(f)
title('Marginal likelihood')

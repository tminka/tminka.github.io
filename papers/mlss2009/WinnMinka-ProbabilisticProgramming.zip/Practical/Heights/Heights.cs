﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer;

namespace Heights
{
	public class Program
	{
		static void Main(string[] args)
		{
			// The probabilistic program
			// -------------------------		
			Variable<double> heightMan = Variable.GaussianFromMeanAndVariance(177,8*8);
			Variable<double> heightWoman = Variable.GaussianFromMeanAndVariance(164, 8*8);

			// The inference
			InferenceEngine engine = new InferenceEngine();
			engine.ShowProgress = false;
			Console.WriteLine("P(man's height) = {0}", engine.Infer(heightMan));
			Console.WriteLine("P(woman's height) = {0}", engine.Infer(heightWoman));

			Console.WriteLine("Press any key...");
			Console.ReadKey();

			// Answer key
			// ----------
			// P(isTaller) = Bernoulli(0.1253)
			// P(man's height|isTaller) = Gaussian(167.7, 37.84)
			// P(woman's height|isTaller) = Gaussian(173.3, 37.84)
		}
	}
}

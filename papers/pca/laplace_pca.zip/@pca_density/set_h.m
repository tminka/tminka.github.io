function obj = set_h(obj, h)

obj.h = h;

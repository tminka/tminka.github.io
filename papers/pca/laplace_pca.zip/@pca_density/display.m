function disp(obj)

disp(['mean = '])
disp(obj.mean)
disp(['subspace = '])
disp(obj.h)
disp(['noise = '])
disp(obj.v)

function p = logProb(obj, data)

p = logProb(asNormal(obj), data);

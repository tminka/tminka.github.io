function pots = read_pots(fname,node_sizes)
% Example: read_pots('example.txt')

if nargin < 2
  node_sizes = 2;
end
m = load(fname);
if length(node_sizes) == 1
  N = max(max(m(:,[1 2])));
  node_sizes = repmat(node_sizes,1,N);
end
C = size(m,1);
pots = {};
for j = 1:C
  dom = m(j,[1 2]);
  T = m(j,3:6);
  ns = node_sizes(dom);
  pots{j} = dpot(dom,ns,T);
end

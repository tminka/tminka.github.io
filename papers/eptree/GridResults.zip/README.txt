The file task_G.mat describes the input networks.  There are 10 networks at
9 sizes, for a total of 90 networks.  Read them into matlab via 'load
task_G.mat'.  The file defines two variables: param and mnets.  

param(i) tells you the size of network i.  

mnets{i}.G describes the variable connections of network i.  G(v1,v2)==1
means variable v1 is connected to variable v2.

mnets{i}.B describes the factor-variable connectivity of network i.  The
rows are factors and the columns are variables, so B(f,v)=1 means that
factor f uses variable v.  You will notice that these networks only have
two-way and one-way factors, with the two-way factors listed first.

mnets{i}.pot{f}.T gives the entries in the table for factor f.  The
variables are all binary, so these tables are either 2x1 or 2x2 matrices.
mnets{i}.pot{f}.domain gives the variables corresponding to the row and
column of the table, respectively.

The file results_G.mat gives the results of different inference algorithms
on these networks.  These are the values used to make figure 3 in the
paper.  The file defines one variable called 'results'.

results.exact{i}.m{v} is the exact marginal of variable v in network i.
results.bp{i}.m{v} is the approximate marginal of variable v in network i,
found by belief propagation at convergence.
results.bp{i}.flops gives the total flopcount for belief propagation to
converge, according to the 5% rule.
The other fields of results correspond to different approximate algorithms.

% EM for the common mean problem, used to produced figure 2 of the paper
% "Expectation-Maximization as lower bound maximization".
% Written by Tom Minka

a = [1 2];
b = [3 4];
na = cols(a);
nb = cols(b);
ma = sum(a)/na;
mb = sum(b)/nb;

% plot the exact posterior
va = var(a,1);
vb = var(b,1);

inc = 0.01;
r = -1:inc:6;
p = (pi*na*((r - ma).^2 + va)).^(-na/2) .* (pi*nb*((r - mb).^2 + vb)).^(-nb/2);
p = p * gamma(na/2) * gamma(nb/2);
figure(1);
clf
plot(r, p);
hold on;

% initial guess for the mean
% m = 2.5 gets stuck
m = 2.6;

for iter = 1:9
  % E-step
  sa = sum((a - repmat(m, 1, na)).^2);
  sb = sum((b - repmat(m, 1, nb)).^2);
  
  % M-step
  m = (na^2/sa*ma + nb^2/sb*mb)/(na^2/sa + nb^2/sb);
  
  if rem(iter, 3) == 1
    % plot the lower bound as a function of m
    r = -1:inc:6;
    lr = length(r);
    p = exp(-sum((repmat(a', 1, lr) - repmat(r, na, 1)).^2)/2*na/sa - ...
	sum((repmat(b', 1, lr) - repmat(r, nb, 1)).^2)/2*nb/sb);
    e = exp(1);
    p = p * exp(-na/2*log(sa*pi/e) -nb/2*log(sb*pi/e));
    p = p * gamma(na/2) * gamma(nb/2);
    h = plot(r, p, 'g--');
    
    %pause
    %delete(h)
  end
end
m

% plot where we landed
%line([m m], [0 0.03], 'Color', 'Red');
xlabel('Theta');
ylabel('f(theta)');
legend('Objective', 'Lower bounds');
% print -dps2 doubleT.ps

if 0
% plot the Aitken curve
ms = 1:0.1:4;
next = [];
for i = 1:length(ms)
  m = ms(i);
  next(i) = common_step(m, a, b);
end
figure(2);
plot(ms, next, ms, ms);
axis([ms(1) ms(length(ms)) 1 4]);
end
if 0
% plot the likelihood as a function of va and vb
vs = 0.1:0.1:4;
for ia = 1:length(vs)
  va = vs(ia);
  for ib = 1:length(vs)
    vb = vs(ib);
    m = (na/va*ma + nb/vb*mb)/(na/va + nb/vb);
    z(ia, ib) = prod(normpdf(a, m, va)) * prod(normpdf(b, m, vb));
  end
end
figure(3);
mesh(vs, vs, z);
rotate3d on;
end
